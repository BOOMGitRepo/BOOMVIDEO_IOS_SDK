//
//  BMNativeAdProperties.h
//  BoomVideoVAST_SDKLibrary
//
//  Created by Algene Pulido on 25/03/2016.
//  Copyright © 2016 BM. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Mediation/BoomMediationAdDelegate.h"
#import "Mediation/BMTeadsType.h"

typedef NS_ENUM(NSInteger,ShowType) {
    Normal,
    Cover
};

/**
 For facebook native ad templates
 */
typedef NS_ENUM(NSInteger,BMNativeAdFBTemplate) {
    /* this are for facebook */
    HEIGHT_100=1,
    HEIGHT_120,
    HEIGHT_300,
    HEIGHT_400,
    Custom1
};

/**
 For boom native ad templates
 */
typedef NS_ENUM(NSInteger,BMNativeAdBoomTemplate) {
    Template1
};

/**
 Properties for the Native Ad.
 */
@interface BMNativeAdProperties : NSObject

/**
 @brief set the GUID if you wish to override the GUID initialized in the credentials.
 */
@property (nonatomic,copy) NSString * _Nonnull GUID;

/**
 @brief set the native ad frame. Note*: this is for all ad networks that has native ad.
 */
@property (nonatomic) CGRect nativeAdFrame;

/**
 @brief set the native ad container view. Note*: this is for all ad networks that has native ad. If this is not set (or nil), You need to manually add the native ad view as a subview in the onNativeAdReady.
 */
@property (nonatomic,strong) UIView * _Nullable containerView;

/**
 @brief display the title and description view. This is not applicable on the comment page. If set to NO, the thumbnail image will occupy the entire native ad unit view. (Default YES) (For Boom only)
 */
//@property (nonatomic) BOOL displayInformation;

/**
 @brief set/get the fb native ad template
 */
@property (nonatomic) BMNativeAdFBTemplate FBTemplate;

/**
 @brief set/get the boom native ad template
 */
@property (nonatomic) BMNativeAdBoomTemplate BoomTemplate;

/**
 @brief set the Teads type to load in
 */
@property (nonatomic,strong) id<BMTeadsType> _Nonnull teadsType;

#pragma clang diagnostic ignored "-Wnullability-completeness"
/**
 the delegate method
 */
@property (nonatomic,weak) id<BoomMediationAdDelegate> delegate;


@end
