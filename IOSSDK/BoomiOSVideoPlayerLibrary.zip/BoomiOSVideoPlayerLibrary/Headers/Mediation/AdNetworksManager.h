//
//  AdNetworksManager.h
//  BoomVideoVAST_SDKLibrary
//
//  Created by Algene Pulido on 11/16/15.
//  Copyright © 2015 BM. All rights reserved.
//
/**
 <p><strong>Millennial Media, Rubicon and MoPub is under development.</strong></p>
 <h1>How To Setup:<h1>
 1. Download Boom SDK and the include folder then include it in your project. For IOS (libBoom***.a and the BoomResources.bundle).
 2. Download and include in your project the necessary sdk's either (.framework, .a) of the ad networks you wish to include in mediation. Please check the documentation of each ad network.
 3. Setup the necessary credentials of each ad network you wish to include like chartboost, ad colony, etc..
 4. FOR IOS:
    Initialize mediation with auto fetch of credentials from server using <code>initMediationFetchCredentialsWithToken:(NSString *) token GUID:(NSString*) guid isLogging:(BOOL) enabled;</code>
    token and guid will be provided by boom.
    <p>You may also initialize mediation with manual input of credentials using</p>
    <code>initMediationWithCredentials:(NSDictionary*) credentials isLogging:(BOOL) enabled;</code>
    <p>Now you can use other methods after initialization. Refer below.</p>
 
 <br>
 
 <h2>Show Mediated Interstitial Ads</h2>
 <p>To show mediated interstitial ads, use the method</p>
 <code>[[AdNetworksManager sharedInstance] showMediatedInterstitialAds];</code>
 
 <h2>Show Mediated Incentivized Ads</h2>
 <p>To show mediated incentivized(rewarded) ads, use the method</p>
 <code>[[AdNetworksManager sharedInstance] showMediatedIncentivizedAds];</code>
 
 <h2>Show Mediated More List Ads (More Apps, Offer List)</h2>
 <p>To show mediated more list ads, use the method</p>
 <code>[[AdNetworksManager sharedInstance] showMediatedMoreList];</code>
 
 <h2>Show Mediated Banner Ads (AdMob only)</h2>
 <p>To show mediated banner ads, use the method (we only have admob banner ads at the moment)</p>
 <code>[[AdNetworksManager sharedInstance] showMediatedBannerAdsWithSize:kBoomGADAdSizeBanner Position:kBannerBottomCenter adUnitId:@"YOUR_AD_UNIT_ID"];
 </code>
 <p>Different banner ad sizes:</p>
 <ul>
    <li>kBoomGADAdSizeBanner</li>
    <li>kBoomGADAdSizeLargeBanner</li>
    <li>kBoomGADAdSizeMediumRectangle</li>
    <li>kBoomGADAdSizeFullBanner</li>
    <li>kBoomGADAdSizeLeaderboard</li>
    <li>kBoomGADAdSizeSkyscraper</li>
 </ul>
 <p>Different banner ad positions:</p>
 <ul>
    <li>kBannerTopLeft</li>
    <li>kBannerTopCenter</li>
    <li>kBannerTopRight</li>
    <li>kBannerBottomLeft</li>
    <li>kBannerBottomCenter</li>
    <li>kBannerBottomRight</li>
 </ul>
 <p><strong>Banner ads automatically adjust when orientation changes.</strong></p>
 
 <br>
 <h2>For Manual Input of Credentials</h2>
 <p>If you wish to input the credentials manually through code, here is an example.</p>
 <code>
 NSMutableDictionary *credentials=[[NSMutableDictionary alloc] init];
 <br>[credentials setValue:@"your adcolony app id" forKey:@kKeyAdColonyAppId];
 <br>[credentials setValue:@"your adcolony interstitial zone id" forKey:@kKeyAdColonyInterstitialZoneId];
 <br>[credentials setValue:@"your adcolony v4vc zone id (incentivized ad)" forKey:@kKeyAdColonyV4VCZoneId];
 <br>
 <br>[[AdNetworksManager sharedInstance] initMediationWithCredentials:credentials isLogging:YES];
 
 </code>
 <p>Please refer to <i>MediationConstants.h</i> for the different keys of different ad networks.</p>
 <br>
 <h1>Very Important! Please add -ObjC in your xcode project Other Linker Flags</h1>
 <h2>Please contact support if you have problems. Thanks!</h2>
*/

#ifndef AdNetworksManager_h
#define AdNetworksManager_h
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "MediationConstants.h"
#import "../BMNativeAdProperties.h"
//#import <TeadsSDK/TeadsSDK.h>
#import "../BMNativeAdView.h"

/**
 Banner ad properties for the ad networks that has banner ad. At the moment we have facebook, admob, and rubicon.
 */
@interface BMBannerAdProperties : NSObject

@property (nonatomic) BoomGADBannerSize AdMobBannerSize;
@property (nonatomic) FBBannerAdSize FBBannerSize;
@property (nonatomic) CGSize RubiconBannerSize;
@property (nonatomic) BoomBannerAdPosition BannerPosition;

@end

@interface AdNetworksManager : NSObject <BoomMediationAdDelegate>

/**
 @brief enable/disable the video auto play feature of all boom native ad unit. When set to YES (enabled), the video will auto play when buffer is at 25%. (Default is YES, enabled auto play. However, if in server side it's NO (false) it will not autoplay).
 */
@property (nonatomic) BOOL nativeAdVideoAutoPlay;

/**
 @brief enable/disable the video auto repeat feature of boom native ad unit. When set to YES (enabled), it will auto repeat the video when playback is finished. (Default is NO, disabled)
 */
@property (nonatomic) BOOL nativeAdVideoAutoRepeat;

/**
 turn on/off location based ads. default is off, all locations.
 */
@property (nonatomic) BOOL isLocationBasedAds;

/**
 @brief singleton instance
 */
+ (AdNetworksManager* _Nonnull) sharedInstance;

/**
 @brief initialize mediation with credentials. Logging is disabled by default.
 */
- (void) initMediationWithCredentials:(NSDictionary* _Nonnull) credentials;

/**
 @brief initialize mediation with credentials
 @param isLogging - enable/disable debug log messages
 */
- (void) initMediationWithCredentials:(NSDictionary* _Nonnull) credentials isLogging:(BOOL) enabled;

/**
 @brief initialize mediation with credentials in JSON format
 @param jsonString - the json string of the credentials. e.g. "{\\"yourkey\\":\\"yourvalue\\"}" \\" is important.
 */
- (void) initMediationWithJSON:(const char* _Nonnull) jsonString;

/**
 @brief initialize mediation with auto fetch credentials from server
 @param token token id given by boom
 @param guid guid given by boom
 @param isLogging set logging enable/disable
 @param completion when fetching is done, this block is called
 */
- (void) initMediationFetchCredentialsWithToken:(NSString * _Nonnull) token GUID:(NSString* _Nonnull) guid isLogging:(BOOL) enabled completion:(void(^)()) onCompletion;

/**
 @brief initialize mediation with auto fetch credentials from server
 @param token token id given by boom
 @param guid guid given by boom
 @param isLogging set logging enable/disable
 */
- (void) initMediationFetchCredentialsWithToken:(NSString * _Nonnull) token GUID:(NSString* _Nonnull) guid isLogging:(BOOL) enabled;

/**
 @brief initialize mediaton with auto fetch credentials from server. Logging is enabled by default.
 @param token token id given by boom
 @param guid guid given by boom
 */
- (void) initMediationFetchCredentialsWithToken:(NSString * _Nonnull) token GUID:(NSString* _Nonnull) guid ;

#pragma mark - SHOW MEDIATED ADS METHODS
/**
 @brief alternately shows the available mediated ad networks
 */
- (void) showMediatedInterstitialAds;

/**
 @brief show more ads lists like offer list or more apps list
 */
- (void) showMediatedMoreList;

/**
 @brief alternately show the available mediated ad networks rewarded/incentive ads
 */
- (void) showMediatedIncentivizedAds;

/**
 @brief show ad mob banner ad
 @param properties the different banner properties to set (size and position)
 */
- (void) showMediatedBannerAdsWithProperties:(BMBannerAdProperties * _Nullable) properties;

/**
 @brief remove the banner from screen
 */
- (void) removeBanner;

/**
 @brief shows the mediation test ui screen for debugging individual ad network
 */
- (void) showMediationTest;

/**
 pre cache a boom preroll, rewarded, or offerlist. If you are using the auto fetch of credentials from server, cache ads only in the completion block same is applied for loading native ads. Note* If you want to cache again for a different ad, you must call this in the delegate method onAdClose or somewhere else after showing an ad.
 */
- (void) cacheBoomAd:(BMCacheableAdType) type;

#pragma mark - SHOW SPECIFIC AD METHODS
/**
 @brief shows interstitial ad for the given ad type
 @param type the ad network type
 */
- (BOOL) showInterstitialForAdType:(AdNetworksType) type;

/**
 @brief shows incentivized ad for the given ad type
 @param type the ad network type
 */
- (BOOL) showIncentivizedForAdType:(AdNetworksType) type;

/**
 @brief shows more list/offer list/more apps ad for the given ad type
 @param type the ad network type
 */
- (BOOL) showMoreListForAdType:(AdNetworksType) type;

/**
 @brief shows banner ad for ad type.
 @param type the ad network type.
 @param properties the different banner properties to set
 */
- (BOOL) showBannerForAdType:(AdNetworksType) type Properties:(BMBannerAdProperties * _Nonnull) properties;

/**
 @brief this will request a native ad with first native ad to request. If the first native ad request fails, it will try to request other ad network and the process repeats until no ad network is avaiable then onAdFail delegate method is called. (WE ONLY HAVE BOOM AND FACEBOOK). NOTE* Do not make multiple calls on this method at a single time. Call it once the first call is done calling the delegate onNativeAdReady or onAdFail.
 @param properties the native ad properties
 */
- (void) loadMediatedNativeAdWithFirstAd:(AdNetworksType) firstAd Properties:(BMNativeAdProperties * _Nonnull) properties;

/**
 create Teads InRead Video in a UITableView with the specified IndexPath. If there is already a successfuly created InRead Video in the specified IndexPath, this method will return nil.
 */
//- (TeadsVideo* _Nullable) createTeadsInReadWithTableView:(UITableView* _Nonnull) tblView IndexPath:(NSIndexPath* _Nonnull) indexPath;
/**
 clears all the index paths stored when creating createTeadsInReadWithTableView. Use this when you need to show teads in other table views. Use it before calling again createTeadsInReadWithTableView;
 */
//- (void) clearTeadsTableViewIndexPaths;

/**
 this will contain a pre loaded mediated native ad (UIView*). If it returns nil, then it has no preloaded native ad for that ad type. (This is only for native ads)
 @param type : the ad network type to check.
 */
- (UIView * _Nullable) preStoredMediatedNativeAdWithType:(AdNetworksType) type;

/**
 returns how many pre stored native ads are there with the given ad network type.
 @param type : the ad network type.
 */
- (NSInteger) preStoredMediatedNativeAdCountWithType:(AdNetworksType) type;

/**
 returns an array of pre stored native ads with the specified type.
 @param type : the ad network type.
 */
- (NSArray * _Nullable) preStoredNativeAdsWithType:(AdNetworksType) type;

/**
 clears the storage of mediated native ads with the given type.
 */
- (void) clearPreStoredMediatedNativeAdsWithType:(AdNetworksType) type;

/**
 if you want to disable a particular ad network type, you can use this method. (All ad networks are enabled by default)
 */
- (void) enableAdNetworkWithType:(AdNetworksType) type enable:(BOOL) enable;

/**
 It is required to set the affiliate id for ad events tracking to work. If this is not set, ad impression, click, etc. will not be tracked.
 @param affiliateID : the affiliate id provided by Boom
 */
- (void) setAffiliateID:(NSString * _Nonnull) affiliateID;

/**
 @brief sets the facebook app id to be used for using facebook social
 */
- (void) setFacebookAppId:(NSString*) appid;

/**
 Add this in the same method in your AppDelegate. This will make sure that all video players of the sdk is set to landscape only. Make sure to set to YES the UIRequiresFullScreen in your Info.plist or check it in your project General settings.
 */
-(UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window;

# pragma mark - TEADS ADS

/**
 @deprecated not used anymore
 @brief Required to call this in your viewDidDisappear.
 */
- (void) viewDidDisappear:(UIViewController * _Nonnull) viewController;
/**
 @deprecated not used anymore
 Required to call this in your viewDidAppear.
 */
- (void) viewDidAppear:(UIViewController * _Nonnull) viewController;

#pragma clang diagnostic ignored "-Wnullability-completeness"
/**
 set the delegate method
 */
@property (nonatomic,weak) id <BoomMediationAdDelegate> delegate;


/**
 If this is YES, it means the sdk is requesting for a landscape only orientation.
 */
@property (nonatomic,readonly) BOOL restrictOrientationToLandscape;

@end

#endif /* AdNetworksManager_h */
