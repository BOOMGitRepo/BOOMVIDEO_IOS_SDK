//
//  BMTeadsType.h
//  BoomVideoVAST_SDKLibrary
//
//  Created by Algene Pulido on 29/04/2016.
//  Copyright © 2016 BM. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BMTeadsType <NSObject,NSCopying>

/**
 set the placementID if you wan't to use a different placementID instead of the one set on credentials initialization.
 */
@property (nonatomic,copy) NSString* placementID;

@end

/*  FOR TABLE VIEW  */
@interface BMTeadsTypeTableView : NSObject  <BMTeadsType>

@property (nonatomic,copy) NSIndexPath *insertionIndexPath;
@property (nonatomic,strong) UITableView* tableView;

@end

/* FOR SCROLL VIEW */
@interface  BMTeadsTypeScrollView : NSObject <BMTeadsType>

@property (nonatomic,strong) UIView *afterView;
@property (nonatomic,strong) UIScrollView *scrollView;

@end

/* FOR SCROLL VIEW AUTO LAYOUT */
@interface BMTeadsTypeScrollViewAutoLayout : NSObject <BMTeadsType>

@property (nonatomic,strong) UIView *forPlaceHolder;
@property (nonatomic,strong) NSLayoutConstraint *withHeightConstraint;
@property (nonatomic,strong) UIScrollView *scrollView;

@end

/* FOR CUSTOM */
@interface BMTeadsTypeCustom : NSObject <BMTeadsType>

//@property (nonatomic,strong) UIView *placeholderView;
@property (nonatomic) CGRect collapsedVideoViewFrame;

@end
